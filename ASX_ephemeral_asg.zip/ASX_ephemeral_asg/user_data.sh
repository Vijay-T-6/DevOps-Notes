#!/bin/bash
yum update -y
yum install -y nginx awslogs

systemctl enable nginx
systemctl start nginx

# Configure awslogs
cat <<EOF > /etc/awslogs/awslogs.conf
[general]
state_file = /var/lib/awslogs/agent-state

[/var/log/messages]
file = /var/log/messages
log_group_name = /ec2/messages
log_stream_name = {instance_id}
datetime_format = %b %d %H:%M:%S
EOF

systemctl enable awslogsd
systemctl start awslogsd
